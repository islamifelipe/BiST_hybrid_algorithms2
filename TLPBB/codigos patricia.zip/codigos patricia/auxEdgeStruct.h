
#ifndef AUXEDGESTRUCT_H
#define AUXEDGESTRUCT_H

struct auxEdgeStruct {

	int a;
	int b;
	double c1;
	double c2;
	double fit;

};

struct fitVecNode {
	int a, b;
	double c;
};

#endif
